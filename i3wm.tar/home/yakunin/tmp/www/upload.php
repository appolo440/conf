<html>
<head>
  <title>Результат загрузки файла</title>
</head>
<body>
<?php

$allowed =  array('zip','gz', 'list');
$filename = $_FILES['filename']['name'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) )
{
    echo 'Filetype Missmach, sorry! :) <br>';
    echo '<a href=../index.php>Home</a>';
    exit;
}
else

//    {
//    echo ("Размер файла превышает три мегабайта");
//    exit;
//    }

    if(is_uploaded_file($_FILES["filename"]["tmp_name"]))
    {
    move_uploaded_file($_FILES["filename"]["tmp_name"], "/var/www/files".$_FILES["filename"]["name"]);
    echo "File is upload!";
    echo "<a href=../index.php>Home</a>";
    }
else
    {
    echo("Error while upload's try again");
    echo "<a href=../index.php>Home</a>";
    }
?>
</body>
</html>