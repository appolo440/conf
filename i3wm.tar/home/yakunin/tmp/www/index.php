<?php

function get_filesize($file)
{
    if(!file_exists($file)) return "Файл  не найден";
    $filesize = filesize($file);
    if($filesize > 1024)
    {
	$filesize = ($filesize/1024);
	if($filesize > 1024)
	{
	$filesize = ($filesize/1024);
	    if($filesize > 1024)
	    {
	    $filesize = ($filesize/1024);
	    $filesize = round($filesize, 1);
	    return $filesize." Gb";
	    }
	    else
	    {
	    $filesize = round($filesize, 1);
	    return $filesize." Mb";
            }
	}
	else
	{
	$filesize = round($filesize, 1);
	return $filesize." Kb";
	}
    }
    else
    {
    $filesize = round($filesize, 1);
    return $filesize." bytes";
    }
}

	$dir=".";
	$i=0;
	if($OpenDir=opendir($dir))
	{
		while(($file=readdir($OpenDir)) !== false)
		if($file != "." && $file != "..")
		{
			$file_extension = strtolower(substr(strrchr($file,"."),1));
			if($file_extension!='php' && $file_extension!='htaccess')
			{
			$i++;
			$color = '#79B0FF';
			if ($i % 2 == 0) $color = '#7F7F7F';
			$size = get_filesize ($file);
			if($size=='4 Kb')
			echo "<a href='$file'><font color='$color'>$file</a> ..</font>";
			else
			echo "<a href='$file'><font color='$color'>$file</a> $size </font>";
			echo "<br>";
			}
		}
	}
else echo "нет прав";

echo "<h2><p><b> Форма для загрузки файлов </b></p></h2>";
echo "<form action=upload.php method=post enctype=multipart/form-data>";
echo "<input type=file name=filename><br>";
echo "<input type=submit value=Go><br>";
echo "</form>";

?>
